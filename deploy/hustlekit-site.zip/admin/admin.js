/* Tiny Apps admin. Sign in with your email, then edit the Instagram kit and your store apps.
   Saved in your Supabase project (same one as Hustle Book). Setup: run admin-setup.sql once. */
const CFG = window.HB_CONFIG || {};
const sb = supabase.createClient(CFG.url, CFG.anonKey);
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const md = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
const slugify = s => String(s || "image").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 50) || "image";
function toast(m, ms){ const t = $("toast"); t.textContent = m; t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(() => t.hidden = true, ms || 2200); }

let kit = null, draftBody = null, running = false, kitStamp = null, savedJSON = "", editing = false, tab = "kit", apps = [], booted = false;
const DRAFT = "tinyadmin.draft";
const dirty = () => kit && JSON.stringify(kit) !== savedJSON;

/* ---------- path helpers: "sections.2.cards.0.title" ---------- */
const keys = p => p.split(".").map(k => /^\d+$/.test(k) ? +k : k);
function get(p){ return keys(p).reduce((o, k) => o == null ? o : o[k], kit); }
function set(p, v){ const ks = keys(p), last = ks.pop(); const o = ks.reduce((o, k) => o[k], kit); o[last] = v; changed(); }
function parentOf(p){ const ks = keys(p), last = ks.pop(); return [ks.reduce((o, k) => o[k], kit), last]; }

/* ================= sign in ================= */
function showGate(msg){
  $("bar").hidden = true;
  $("screen").innerHTML = `<form class="gate" id="gate">
    <h1>Tiny Apps admin</h1>
    <p class="muted">Sign in with your email. We'll email you a 6-digit code.</p>
    <label>Your email<input id="gEmail" type="email" required autocomplete="email"></label>
    <button class="primary" id="gSend">Email me a code</button>
    <div id="gCodeBox" hidden style="display:flex;flex-direction:column;gap:10px">
      <label>6-digit code<input id="gCode" inputmode="numeric" autocomplete="one-time-code" maxlength="8"></label>
      <button type="button" class="primary" id="gVerify">Sign in</button>
    </div>
    <p class="err" id="gErr" ${msg ? "" : "hidden"}>${esc(msg || "")}</p>
  </form>`;
  const err = m => { $("gErr").textContent = m; $("gErr").hidden = !m; };
  $("gate").addEventListener("submit", async e => {
    e.preventDefault(); err("");
    const email = $("gEmail").value.trim(); $("gSend").disabled = true; $("gSend").textContent = "Sending…";
    const { error } = await sb.auth.signInWithOtp({ email, options: { emailRedirectTo: location.origin + "/admin/" } });
    $("gSend").disabled = false; $("gSend").textContent = "Send again";
    if (error) return err("That didn't send: " + error.message);
    $("gCodeBox").hidden = false; $("gCode").focus();
    toast("Check your email (and spam) for the code");
  });
  $("gVerify").addEventListener("click", async () => {
    err(""); const email = $("gEmail").value.trim(), token = $("gCode").value.trim();
    if (!token) return err("Type the code from the email.");
    $("gVerify").disabled = true;
    const { error } = await sb.auth.verifyOtp({ email, token, type: "email" });
    $("gVerify").disabled = false;
    if (error) return err("That code didn't work. Check it, or send a new one.");
    start();
  });
}

async function start(){
  if (running || booted) return; running = true;
  try { await boot(); } finally { running = false; }
}
async function boot(){
  if (!CFG.url || !CFG.anonKey) { $("screen").innerHTML = `<p class="err center">Supabase isn't set up in hustle-book-online/js/config.js.</p>`; return; }
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return showGate();
  const { data: ok, error } = await sb.rpc("claim_admin");
  if (error) return showSetup(error);
  if (!ok) {
    $("bar").hidden = true;
    $("screen").innerHTML = `<div class="gate"><h1>Not allowed</h1><p>${esc(session.user.email)} isn't the admin of this site.</p><button class="ghost" id="so2">Sign out</button></div>`;
    $("so2").onclick = signOut; return;
  }
  booted = true;
  $("bar").hidden = false;
  document.documentElement.style.setProperty("--barh", $("bar").offsetHeight + "px");
  await loadKit();
  showTab(location.hash === "#apps" ? "apps" : location.hash === "#links" ? "links" : "kit");
}
function showSetup(error){
  $("bar").hidden = true;
  $("screen").innerHTML = `<div class="gate"><h1>One setup step</h1>
    <p>The admin's database tables aren't in Supabase yet. Open Supabase → SQL Editor → New query, paste the whole <b>admin-setup.sql</b> file, press Run, then reload this page.</p>
    <p class="note">Details: ${esc(error?.message || "")}</p></div>`;
}
async function signOut(){
  if (dirty() && !confirm("You have changes that aren't saved. Sign out anyway?")) return;
  await sb.auth.signOut(); location.reload();
}

/* ================= tabs ================= */
function showTab(t){
  if (tab === "kit" && t !== "kit" && editing) setEditing(false);
  tab = t;
  document.querySelectorAll("[data-tab]").forEach(b => b.classList.toggle("on", b.dataset.tab === t));
  $("editBtn").hidden = t !== "kit";
  $("saveBtn").hidden = t !== "kit" || !editing;
  history.replaceState(null, "", t === "kit" ? location.pathname : "#" + t);
  if (t === "kit") renderKit(); else if (t === "apps") loadApps(); else renderLinks();
  window.scrollTo(0, 0);
}
document.addEventListener("click", e => { const b = e.target.closest("[data-tab]"); if (b) showTab(b.dataset.tab); });
$("signOut").onclick = signOut;
$("editBtn").onclick = () => setEditing(!editing);
$("saveBtn").onclick = saveKit;
function setEditing(on){
  editing = on;
  document.body.classList.toggle("editing", on);
  $("editBtn").textContent = on ? "Done editing" : "Edit page";
  $("saveBtn").hidden = !on;
  renderKit(true);
}

/* ================= Instagram kit ================= */
async function loadKit(){
  const { data, error } = await sb.from("admin_docs").select("body,updated_at").eq("key", "instagram").maybeSingle();
  if (error) { toast("Couldn't load the kit: " + error.message, 5000); kit = { sections: [] }; savedJSON = JSON.stringify(kit); return; }
  kit = data ? data.body : { title: "Instagram kit", sections: [] };
  kitStamp = data ? data.updated_at : null;
  savedJSON = JSON.stringify(kit);
  let d = null; try { d = JSON.parse(localStorage.getItem(DRAFT)); } catch (e) {}
  if (d && d.base === kitStamp && JSON.stringify(d.body) !== savedJSON) draftBody = d.body;
}
function changed(){
  try { localStorage.setItem(DRAFT, JSON.stringify({ base: kitStamp, body: kit })); } catch (e) {}
  $("saveBtn").textContent = dirty() ? "Save changes •" : "Saved";
}
window.addEventListener("beforeunload", e => { if (dirty()) { e.preventDefault(); e.returnValue = ""; } });

async function saveKit(){
  const btn = $("saveBtn"); btn.disabled = true; btn.textContent = "Saving…";
  const { data: cur } = await sb.from("admin_docs").select("updated_at").eq("key", "instagram").maybeSingle();
  if (cur && kitStamp && cur.updated_at !== kitStamp && !confirm("This page was saved from another device since you opened it. Save yours over it? (The other one stays in History.)")) { btn.disabled = false; changed(); return; }
  const { data, error } = await sb.from("admin_docs").upsert({ key: "instagram", body: kit }).select("updated_at").single();
  btn.disabled = false;
  if (error) { btn.textContent = "Save changes •"; return toast("Not saved: " + error.message, 6000); }
  kitStamp = data.updated_at; savedJSON = JSON.stringify(kit);
  try { localStorage.removeItem(DRAFT); } catch (e) {}
  changed(); toast("Saved");
}

/* editable text: in edit mode it's a contenteditable field tied to a path */
function T(path, tag = "span", cls = "", ph = ""){
  const v = get(path) ?? "";
  if (!editing) return `<${tag}${cls ? ` class="${cls}"` : ""}>${md(v)}</${tag}>`;
  return `<${tag} class="${cls}" contenteditable="true" spellcheck="true" data-path="${path}" data-ph="${esc(ph)}">${esc(v)}</${tag}>`;
}
const X = (path, label = "Remove") => editing ? `<button type="button" class="small ghost danger" data-act="del" data-path="${path}" title="${label}" aria-label="${label}">✕</button>` : "";
const MV = path => editing ? `<button type="button" class="small ghost" data-act="up" data-path="${path}" aria-label="Move up">↑</button><button type="button" class="small ghost" data-act="down" data-path="${path}" aria-label="Move down">↓</button>` : "";
const imgSrc = s => s;

function renderKit(keepScroll){
  if (tab !== "kit") return;
  const y = window.scrollY;
  const k = kit;
  const draftBanner = draftBody ? `<div class="banner"><span>You have edits from last time that weren't saved.</span><span class="tools"><button class="small primary" data-act="draft-keep">Bring them back</button><button class="small ghost" data-act="draft-drop">Throw away</button></span></div>` : "";
  const nav = `<nav class="jump" aria-label="Sections">${(k.sections || []).map((s, i) => `<a href="#sec-${i}">${esc(s.title || "Section")}</a>`).join("")}</nav>`;
  const head = `<header class="intro">
    <h1>${T("title")} ${T("accent", "span", "acc")}</h1>
    ${T("intro", "p", "lead", "Intro text")}
    ${k.tip || editing ? T("tip", "div", "tip", "Tip box") : ""}
    ${editing ? `<div class="tools"><button class="small" data-act="history">History (undo a save)</button></div>` : ""}
  </header>`;
  const secs = (k.sections || []).map((s, i) => renderSection(s, i)).join("");
  const addSec = editing ? `<div class="adds"><button data-act="add-section">+ Add a section</button></div>` : "";
  $("screen").innerHTML = draftBanner + head + nav + secs + addSec;
  if (keepScroll) window.scrollTo({ top: y, behavior: "instant" });
}

function renderSection(s, i){
  const p = `sections.${i}`;
  const layout = s.layout === "grid" ? "grid" : s.layout === "two" ? "two" : "";
  const table = s.table ? renderTable(s.table, `${p}.table`) : "";
  const cards = (s.cards || []).map((c, j) => renderCard(c, `${p}.cards.${j}`)).join("");
  const tools = editing ? `<div class="tools">${MV(p)}${X(p, "Delete section")}
      <label class="check" style="font-weight:500">Layout <select data-act="layout" data-path="${p}.layout" style="width:auto;padding:4px 8px">
      ${[["one", "One column"], ["grid", "Big cards"], ["two", "Small cards"]].map(([v, l]) => `<option value="${v}"${(s.layout || "one") === v ? " selected" : ""}>${l}</option>`).join("")}</select></label></div>` : "";
  const adds = editing ? `<div class="adds"><button class="small" data-act="add-card" data-path="${p}">+ Add a card</button>${s.table ? "" : `<button class="small" data-act="add-table" data-path="${p}">+ Add a table</button>`}</div>` : "";
  return `<section class="sec" id="sec-${i}">
    ${tools}
    ${T(`${p}.title`, "h2", "", "Section title")}
    ${s.sub || editing ? T(`${p}.sub`, "p", "sub", "Short description") : ""}
    ${table}
    ${cards ? `<div class="cards ${layout}">${cards}</div>` : ""}
    ${adds}
  </section>`;
}

function kindClass(t){ t = String(t).toLowerCase(); return t.includes("reel") ? "k-reel" : t.includes("carousel") ? "k-carousel" : t.includes("feed") || t.includes("post") ? "k-feed" : ""; }
function renderTable(t, p){
  const head = `<tr>${t.cols.map((c, j) => `<th>${T(`${p}.cols.${j}`)}</th>`).join("")}${editing ? "<th></th>" : ""}</tr>`;
  const rows = t.rows.map((r, i) => `<tr>${r.map((c, j) => `<td>${j === 1 && !editing ? `<span class="kind ${kindClass(c)}">${esc(c)}</span>` : T(`${p}.rows.${i}.${j}`)}</td>`).join("")}${editing ? `<td><span class="tools">${MV(`${p}.rows.${i}`)}${X(`${p}.rows.${i}`, "Delete row")}</span></td>` : ""}</tr>`).join("");
  const adds = editing ? `<div class="adds"><button class="small" data-act="add-row" data-path="${p}.rows">+ Add a row</button><button class="small ghost danger" data-act="del" data-path="${p}">Remove table</button></div>` : "";
  return `<div class="tablewrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${adds}`;
}

function renderCard(c, p){
  const imgs = c.images || [];
  const metas = (c.meta || []).map((m, i) => editing ? `<span class="row-x">${T(`${p}.meta.${i}`)}${X(`${p}.meta.${i}`)}</span>` : `<span>${md(m)}</span>`).join("");
  const list = (c.list || []).map((l, i) => `<li>${editing ? `<span class="row-x">${T(`${p}.list.${i}`, "span", "", "Step")}${X(`${p}.list.${i}`)}</span>` : md(l)}</li>`).join("");
  const text = (c.text || []).map((t, i) => editing ? `<div class="row-x">${T(`${p}.text.${i}`, "p", "", "Paragraph")}${X(`${p}.text.${i}`)}</div>` : `<p>${md(t)}</p>`).join("");
  const figs = imgs.map((im, i) => `<figure>
      <img src="${esc(imgSrc(im.src))}" alt="${esc((c.title || "Image") + " " + (i + 1))}" loading="lazy">
      <figcaption><button type="button" class="small" data-act="dl" data-path="${p}" data-i="${i}">Download</button>${editing ? `<button class="small ghost" data-act="left" data-path="${p}.images.${i}" aria-label="Move left">←</button><button class="small ghost" data-act="right" data-path="${p}.images.${i}" aria-label="Move right">→</button>${X(`${p}.images.${i}`, "Remove image")}` : ""}</figcaption>
    </figure>`).join("");
  const imgBlock = imgs.length || editing ? `<div class="strip${c.tall ? " tall" : ""}">${figs}</div>
      <div class="imgbar">${imgs.length > 1 ? `<button type="button" class="small" data-act="dlall" data-path="${p}">Download all ${imgs.length} (zip)</button>` : ""}${editing ? `<button class="small" data-act="add-img" data-path="${p}">+ Add images</button><label class="check" style="font-weight:500"><input type="checkbox" data-act="tall" data-path="${p}.tall"${c.tall ? " checked" : ""}> Tall images (stories, reels)</label>` : ""}</div>` : "";
  const copies = (c.copies || []).map((cp, i) => `<div class="cap"><div class="cap-head">${T(`${p}.copies.${i}.label`, "span", "lbl", "Label")}<span class="tools"><button type="button" class="small" data-act="copy" data-path="${p}.copies.${i}.text">Copy</button>${X(`${p}.copies.${i}`, "Remove caption")}</span></div>${editing ? T(`${p}.copies.${i}.text`, "div", "captext", "Caption") : `<pre class="captext">${esc(cp.text)}</pre>`}</div>`).join("");
  const adds = editing ? `<div class="adds">
      <button class="small" data-act="push" data-path="${p}.meta" data-v="New label">+ Label</button>
      <button class="small" data-act="push" data-path="${p}.list" data-v="New step">+ Step</button>
      <button class="small" data-act="push" data-path="${p}.text" data-v="New paragraph">+ Paragraph</button>
      <button class="small" data-act="push-cap" data-path="${p}.copies">+ Caption to copy</button>
      ${c.box == null ? `<button class="small" data-act="setstr" data-path="${p}.box">+ Highlight box</button>` : ""}
      ${c.note == null ? `<button class="small" data-act="setstr" data-path="${p}.note">+ Small note</button>` : ""}
    </div>` : "";
  return `<div class="card">
    ${editing ? `<div class="tools end">${MV(p)}${X(p, "Delete card")}</div>` : ""}
    ${T(`${p}.title`, "h3", "", "Card title")}
    ${metas ? `<div class="meta">${metas}</div>` : ""}
    ${list ? `<ol class="list">${list}</ol>` : ""}
    ${c.box != null ? `<div class="row-x">${T(`${p}.box`, "div", "box", "Highlight box")}${X(`${p}.box`)}</div>` : ""}
    ${imgBlock}
    ${text ? `<div class="text">${text}</div>` : ""}
    ${copies}
    ${c.note != null ? `<div class="row-x">${T(`${p}.note`, "p", "note", "Note")}${X(`${p}.note`)}</div>` : ""}
    ${adds}
  </div>`;
}

/* typing in an editable field */
document.addEventListener("input", e => {
  const el = e.target.closest("[contenteditable][data-path]");
  if (el) set(el.dataset.path, el.innerText.replace(/\n$/, ""));
});
document.addEventListener("paste", e => {
  const el = e.target.closest("[contenteditable]"); if (!el) return;
  e.preventDefault(); document.execCommand("insertText", false, e.clipboardData.getData("text/plain"));
});
document.addEventListener("change", e => {
  const t = e.target; if (!t.dataset || !t.dataset.act || tab !== "kit") return;
  if (t.dataset.act === "layout") { set(t.dataset.path, t.value); renderKit(true); }
  if (t.dataset.act === "tall") { set(t.dataset.path, t.checked); renderKit(true); }
});

let pendingImgPath = null;
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-act]"); if (!b || tab !== "kit" || b.tagName === "SELECT" || b.type === "checkbox") return;
  const a = b.dataset.act, p = b.dataset.path;
  if (a === "copy") return copyText(get(p));
  if (a === "dl") { const c = get(p), i = +b.dataset.i; return downloadOne(c.images[i].src, fileName(c, i)); }
  if (a === "dlall") return downloadAll(get(p));
  if (a === "history") return showHistory();
  if (a === "draft-keep") { kit = draftBody; draftBody = null; changed(); if (!editing) setEditing(true); else renderKit(true); return toast("Edits brought back. Press Save to keep them."); }
  if (a === "draft-drop") { draftBody = null; try { localStorage.removeItem(DRAFT); } catch (err) {} return renderKit(true); }
  if (a === "add-img") { pendingImgPath = p; $("filePick").value = ""; return $("filePick").click(); }
  if (a === "del") {
    const [o, k] = parentOf(p);
    if (/^sections\.\d+$/.test(p) && !confirm("Delete this whole section?")) return;
    if (/cards\.\d+$/.test(p) && !confirm("Delete this card?")) return;
    Array.isArray(o) ? o.splice(k, 1) : delete o[k];
  } else if (a === "up" || a === "down" || a === "left" || a === "right") {
    const [o, k] = parentOf(p), to = k + (a === "up" || a === "left" ? -1 : 1);
    if (to < 0 || to >= o.length) return;
    [o[k], o[to]] = [o[to], o[k]];
  } else if (a === "push") {
    const arr = get(p); if (arr) arr.push(b.dataset.v); else set(p, [b.dataset.v]);
  } else if (a === "push-cap") {
    const arr = get(p), v = { label: "Caption", text: "Write your caption here" }; if (arr) arr.push(v); else set(p, [v]);
  } else if (a === "setstr") { set(p, "New text");
  } else if (a === "add-card") { const s = get(p); (s.cards = s.cards || []).push({ title: "New card", images: [], copies: [{ label: "Caption", text: "Write your caption here" }] });
  } else if (a === "add-table") { get(p).table = { cols: ["Day", "What", "Post"], rows: [["", "", ""]] };
  } else if (a === "add-row") { const rows = get(p); rows.push(rows[0] ? rows[0].map(() => "") : ["", "", ""]);
  } else if (a === "add-section") { (kit.sections = kit.sections || []).push({ id: "s" + Date.now(), title: "New section", sub: "", layout: "grid", cards: [] });
  } else return;
  changed(); renderKit(true);
});

$("filePick").addEventListener("change", async () => {
  const files = [...$("filePick").files]; if (!files.length || !pendingImgPath) return;
  const card = get(pendingImgPath); card.images = card.images || [];
  toast("Uploading " + files.length + " image" + (files.length > 1 ? "s" : "") + "…", 60000);
  for (const f of files) {
    const ext = (f.name.match(/\.[a-z0-9]+$/i) || [".png"])[0].toLowerCase();
    const path = `${Date.now()}-${slugify(f.name.replace(/\.[^.]+$/, ""))}${ext}`;
    const { error } = await sb.storage.from("kit-images").upload(path, f, { contentType: f.type || "image/png" });
    if (error) { toast("Upload failed: " + error.message, 6000); break; }
    card.images.push({ src: sb.storage.from("kit-images").getPublicUrl(path).data.publicUrl });
  }
  changed(); renderKit(true); toast("Added. Press Save changes to keep it.");
});

/* copy + download */
async function copyText(t){
  try { await navigator.clipboard.writeText(t); toast("Copied"); }
  catch (e) { const ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); toast("Copied"); } catch (er) { toast("Select the text and copy it"); } ta.remove(); }
}
function fileName(card, i){
  const n = (card.images || []).length, src = card.images[i].src;
  const ext = (src.split("?")[0].match(/\.(png|jpe?g|webp|gif)$/i) || [".png"])[0].toLowerCase();
  return slugify(card.title) + (n > 1 ? "-" + (i + 1) : "") + ext;
}
async function blobOf(src){ const r = await fetch(src); if (!r.ok) throw new Error(r.status); return r.blob(); }
function saveBlob(blob, name){
  const u = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 5000);
}
async function downloadOne(src, name){
  try { saveBlob(await blobOf(src), name); } catch (e) { window.open(src, "_blank"); }
}
let zipLib = null;
function loadZip(){
  return zipLib || (zipLib = new Promise((res, rej) => { const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"; s.onload = () => res(window.JSZip); s.onerror = rej; document.head.appendChild(s); }));
}
async function downloadAll(card){
  toast("Making your zip…", 30000);
  try {
    const JSZip = await loadZip(), zip = new JSZip();
    for (let i = 0; i < card.images.length; i++) zip.file(fileName(card, i), await blobOf(card.images[i].src));
    saveBlob(await zip.generateAsync({ type: "blob" }), slugify(card.title) + ".zip");
    toast("Downloaded");
  } catch (e) {
    toast("Zip didn't work, downloading one by one");
    for (let i = 0; i < card.images.length; i++) { await downloadOne(card.images[i].src, fileName(card, i)); await new Promise(r => setTimeout(r, 400)); }
  }
}

/* history */
async function showHistory(){
  const { data, error } = await sb.from("admin_doc_versions").select("id,saved_at").eq("key", "instagram").order("id", { ascending: false }).limit(50);
  if (error) return toast(error.message, 5000);
  const d = document.createElement("dialog");
  d.innerHTML = `<h3 style="font-size:26px">Earlier versions</h3>
    <p class="note">Pick one to load it into the editor. Nothing changes until you press Save changes.</p>
    <div class="vlist">${data.length ? data.map(v => `<div><span>${esc(new Date(v.saved_at).toLocaleString())}</span><button class="small" data-v="${v.id}">Load</button></div>`).join("") : "<p class='muted'>No earlier saves yet.</p>"}</div>
    <button class="ghost" data-close>Close</button>`;
  document.body.appendChild(d); d.showModal();
  d.addEventListener("close", () => d.remove());
  d.addEventListener("click", async e => {
    if (e.target.dataset.close != null) return d.close();
    const id = e.target.dataset.v; if (!id) return;
    const { data: v } = await sb.from("admin_doc_versions").select("body").eq("id", id).single();
    if (v) { kit = v.body; changed(); d.close(); if (!editing) setEditing(true); else renderKit(); toast("Loaded. Press Save changes to keep this version."); }
  });
}

/* ================= Apps ================= */
const BLANK_APP = { slug: "", name: "", price: 12, planId: "", appUrl: "", short: "", lede: "", who: [], features: [], privacy: "" };
async function loadApps(){
  $("screen").innerHTML = `<p class="muted">Loading apps…</p>`;
  const { data, error } = await sb.from("store_apps").select("*").order("sort").order("slug");
  if (error) { $("screen").innerHTML = `<p class="err">Couldn't load apps: ${esc(error.message)}</p>`; return; }
  apps = data; renderApps();
}
function renderApps(){
  const rows = apps.map((a, i) => `<div class="approw">
      <span class="icon" aria-hidden="true">${esc((a.data.name || "?")[0])}</span>
      <span class="info"><b>${esc(a.data.name || a.slug)}</b><span class="muted">US$${esc(a.data.price)} / month · /#${esc(a.slug)}</span></span>
      <span class="pill ${a.published ? "live" : "off"}">${a.published ? "In the store" : "Hidden"}</span>
      <span class="tools"><button class="small ghost" data-app="up" data-i="${i}" aria-label="Move up">↑</button><button class="small ghost" data-app="down" data-i="${i}" aria-label="Move down">↓</button>
      <a class="btn small ghost" href="../#${esc(a.slug)}" target="_blank" rel="noopener">View</a><button class="small" data-app="edit" data-i="${i}">Edit</button></span>
    </div>`).join("");
  $("screen").innerHTML = `<header class="intro"><h1>Your <span class="acc">apps</span></h1>
    <p class="lead">These are the apps in your store. Changes show on the store as soon as you save. Hidden apps stay here but customers don't see them.</p></header>
    <div class="applist">${rows || "<p class='muted'>No apps yet.</p>"}</div>
    <div><button class="primary" data-app="new">+ Add a new app</button></div>`;
}
function appForm(rec){
  const a = Object.assign({}, BLANK_APP, rec ? rec.data : {});
  const feats = (a.features || []).map(f => featRow(f[0], f[1])).join("");
  $("screen").innerHTML = `<button class="ghost" data-app="back">← All apps</button>
  <form class="panel" id="appForm">
    <h2 style="font-size:34px">${rec ? "Edit " + esc(a.name) : "New app"}</h2>
    <div class="form">
      <label>App name<input name="name" required value="${esc(a.name)}"></label>
      <label>Link name <small>Lowercase and dashes, e.g. hustle-book. Used in the store link.</small><input name="slug" required pattern="[a-z0-9-]{2,40}" value="${esc(rec ? rec.slug : a.slug)}"></label>
      <label>Price per month (US$)<input name="price" type="number" min="0" step="0.01" required value="${esc(a.price)}"></label>
      <label>PayPal plan ID <small>PayPal → Subscriptions → your plan. Leave empty until you have one.</small><input name="planId" value="${esc(/PASTE_/.test(a.planId) ? "" : a.planId)}" placeholder="P-..."></label>
      <label class="full">App link <small>Where subscribers go after paying, e.g. hustle-book/ or a full https:// link</small><input name="appUrl" value="${esc(a.appUrl)}"></label>
      <label class="full">Short description <small>On the store's front page</small><textarea name="short" style="min-height:70px">${esc(a.short)}</textarea></label>
      <label class="full">Long description <small>At the top of the app's own page</small><textarea name="lede">${esc(a.lede)}</textarea></label>
      <label class="full">Who it's for <small>One per line</small><textarea name="who">${esc((a.who || []).join("\n"))}</textarea></label>
      <div class="full" style="display:flex;flex-direction:column;gap:6px"><b style="font-size:13.5px">What you get</b><span class="note">A short title and one sentence for each feature.</span>
        <div id="feats" style="display:flex;flex-direction:column;gap:6px">${feats}</div>
        <div><button type="button" class="small" data-app="feat">+ Add a feature</button></div></div>
      <label class="full">Privacy note <small>Optional, shown under the features</small><input name="privacy" value="${esc(a.privacy)}"></label>
      <label class="check full"><input type="checkbox" name="published"${!rec || rec.published ? " checked" : ""}> Show this app in the store</label>
    </div>
    <div class="tools"><button class="primary" type="submit">Save app</button><button type="button" class="ghost" data-app="back">Cancel</button>${rec ? `<span style="flex:1"></span><button type="button" class="ghost danger" data-app="delete">Delete app</button>` : ""}</div>
    <p class="err" id="appErr" hidden></p>
  </form>`;
  $("appForm").onsubmit = e => { e.preventDefault(); saveApp(rec); };
  $("appForm").dataset.orig = rec ? rec.slug : "";
}
const featRow = (t = "", d = "") => `<div class="feat"><input placeholder="Title" value="${esc(t)}" aria-label="Feature title"><input placeholder="One sentence about it" value="${esc(d)}" aria-label="Feature description"><button type="button" class="small ghost danger" data-app="unfeat" aria-label="Remove feature">✕</button></div>`;
async function saveApp(rec){
  const f = $("appForm"), v = n => f.elements[n].value.trim(), err = $("appErr");
  const slug = v("slug").toLowerCase();
  const data = {
    slug, name: v("name"), price: Number(v("price")), planId: v("planId") || "PASTE_PLAN_ID", appUrl: v("appUrl"),
    short: v("short"), lede: v("lede"), who: v("who").split("\n").map(s => s.trim()).filter(Boolean),
    features: [...f.querySelectorAll(".feat")].map(r => [r.children[0].value.trim(), r.children[1].value.trim()]).filter(x => x[0] || x[1]),
    privacy: v("privacy")
  };
  if (!rec && apps.some(a => a.slug === slug)) { err.textContent = "Another app already uses that link name."; err.hidden = false; return; }
  const row = { slug, data, published: f.elements.published.checked, sort: rec ? rec.sort : (apps.reduce((m, a) => Math.max(m, a.sort), 0) + 1), updated_at: new Date().toISOString() };
  const { error } = await sb.from("store_apps").upsert(row);
  if (error) { err.textContent = "Not saved: " + error.message; err.hidden = false; return; }
  if (rec && rec.slug !== slug) await sb.from("store_apps").delete().eq("slug", rec.slug);
  toast("Saved. It's live on the store."); loadApps();
}
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-app]"); if (!b || tab !== "apps") return;
  const a = b.dataset.app, i = +b.dataset.i;
  if (a === "edit") appForm(apps[i]);
  else if (a === "new") appForm(null);
  else if (a === "back") renderApps();
  else if (a === "feat") $("feats").insertAdjacentHTML("beforeend", featRow());
  else if (a === "unfeat") b.closest(".feat").remove();
  else if (a === "delete") {
    const slug = $("appForm").dataset.orig;
    if (!confirm("Delete this app from the store for good? (To just take it down, untick \"Show this app in the store\" instead.)")) return;
    const { error } = await sb.from("store_apps").delete().eq("slug", slug);
    if (error) return toast(error.message, 5000);
    toast("Deleted"); loadApps();
  } else if (a === "up" || a === "down") {
    const j = i + (a === "up" ? -1 : 1); if (j < 0 || j >= apps.length) return;
    [apps[i], apps[j]] = [apps[j], apps[i]];
    apps.forEach((x, n) => x.sort = n + 1);
    renderApps();
    const { error } = await sb.from("store_apps").upsert(apps.map(x => ({ slug: x.slug, sort: x.sort, published: x.published, data: x.data })));
    if (error) toast("Order not saved: " + error.message, 5000);
  }
});

/* ================= Links ================= */
function renderLinks(){
  const L = [
    ["Your store", "../", "What customers see"],
    ["Hustle Book", "../hustle-book/", "The app subscribers use"],
    ["Hustle Book online", "../hustle-book-online/", "The version that saves to Supabase"],
    ["Instagram", "https://www.instagram.com/hustlekit.bb/", "@hustlekit.bb"],
    ["PayPal subscriptions", "https://www.paypal.com/billing/subscriptions", "Plans and subscribers"],
    ["Supabase", "https://supabase.com/dashboard/projects", "Your database"],
    ["Cloudflare", "https://dash.cloudflare.com/", "Workers & Pages → hustlekit"],
    ["Meta Business Suite", "https://business.facebook.com/latest/inbox", "DMs and auto replies"]
  ];
  $("screen").innerHTML = `<header class="intro"><h1>Handy <span class="acc">links</span></h1></header>
    <div class="links">${L.map(([t, h, s]) => `<a href="${h}" target="_blank" rel="noopener"><b>${t}</b><span>${s}</span></a>`).join("")}</div>`;
}

sb.auth.onAuthStateChange(ev => { if (ev === "SIGNED_IN" && !booted) setTimeout(start, 0); });
window.addEventListener("resize", () => { if (!$("bar").hidden) document.documentElement.style.setProperty("--barh", $("bar").offsetHeight + "px"); });
start();
